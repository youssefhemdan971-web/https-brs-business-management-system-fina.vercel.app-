import { clampMoney, uid, today } from "./store.js";

export const movementTypes = {
  purchase: { label: "إضافة شراء", sign: 1 },
  return: { label: "مرتجع للعميل", sign: 1 },
  damage: { label: "تالف", sign: -1 },
  adjustment_in: { label: "تسوية إضافة", sign: 1 },
  adjustment_out: { label: "تسوية خصم", sign: -1 },
  sale: { label: "بيع", sign: -1 }
};

export function findProduct(state, id) {
  return state.products.find(p => p.id === id) || null;
}

export function productByName(state, name) {
  const q = String(name || "").trim().toLocaleLowerCase();
  return state.products.find(p => p.name.toLocaleLowerCase() === q) || null;
}

export function stockValue(state) {
  return state.products.reduce((sum, p) => sum + Number(p.stock || 0) * Number(p.cost || 0), 0);
}

export function isLowStock(product) {
  return Number(product.stock || 0) <= Number(product.reorderLevel || 0);
}

export function createProduct(state, input) {
  const name = String(input.name || "").trim();
  const sku = String(input.sku || "").trim();
  const stock = Number(input.stock);
  const cost = Number(input.cost);
  const price = Number(input.price);
  const reorderLevel = Number(input.reorderLevel);

  if (!name) throw new Error("اسم الصنف مطلوب.");
  if (!sku) throw new Error("كود الصنف مطلوب.");
  if (![stock, cost, price, reorderLevel].every(Number.isFinite)) throw new Error("قيم المخزن غير صحيحة.");
  if (stock < 0 || cost < 0 || price < 0 || reorderLevel < 0) throw new Error("لا يمكن إدخال قيمة سالبة.");
  if (state.products.some(p => p.sku.toLowerCase() === sku.toLowerCase())) throw new Error("كود الصنف موجود بالفعل.");

  const product = {
    id: uid("prd"),
    name, sku,
    category: String(input.category || "عام").trim(),
    size: String(input.size || "").trim(),
    unit: String(input.unit || "قطعة").trim() || "قطعة",
    stock, cost, price, reorderLevel,
    createdAt: new Date().toISOString()
  };
  state.products.push(product);

  if (stock > 0) {
    state.movements.push({
      id: uid("mov"), productId: product.id, productName: product.name,
      type: "opening", typeLabel: "رصيد افتتاحي", qty: stock,
      before: 0, after: stock, date: today(), note: "رصيد افتتاحي"
    });
  }
  return product;
}

export function updateProduct(state, id, input) {
  const p = findProduct(state, id);
  if (!p) throw new Error("الصنف غير موجود.");

  const nextStock = Number(input.stock);
  const cost = Number(input.cost);
  const price = Number(input.price);
  const reorderLevel = Number(input.reorderLevel);

  if (!String(input.name || "").trim() || !String(input.sku || "").trim()) throw new Error("اسم الصنف والكود مطلوبان.");
  if (![nextStock, cost, price, reorderLevel].every(Number.isFinite) || nextStock < 0 || cost < 0 || price < 0 || reorderLevel < 0) {
    throw new Error("بيانات الصنف غير صحيحة.");
  }

  const duplicate = state.products.find(x => x.id !== id && x.sku.toLowerCase() === String(input.sku).trim().toLowerCase());
  if (duplicate) throw new Error("كود الصنف مستخدم في صنف آخر.");

  const oldStock = Number(p.stock);
  Object.assign(p, {
    name: String(input.name).trim(),
    sku: String(input.sku).trim(),
    category: String(input.category || "عام").trim(),
    size: String(input.size || "").trim(),
    unit: String(input.unit || "قطعة").trim() || "قطعة",
    stock: nextStock, cost, price, reorderLevel,
    updatedAt: new Date().toISOString()
  });

  if (oldStock !== nextStock) {
    state.movements.push({
      id: uid("mov"), productId: p.id, productName: p.name,
      type: "adjustment", typeLabel: "تعديل رصيد",
      qty: nextStock - oldStock, before: oldStock, after: nextStock,
      date: today(), note: "تعديل مباشر من بيانات الصنف"
    });
  }
  return p;
}

export function applyMovement(state, { productId, type, qty, note = "", reference = "" }) {
  const p = findProduct(state, productId);
  if (!p) throw new Error("الصنف غير موجود.");

  const amount = Number(qty);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("الكمية يجب أن تكون أكبر من صفر.");

  const def = movementTypes[type];
  if (!def) throw new Error("نوع الحركة غير معروف.");

  const before = Number(p.stock || 0);
  const after = before + def.sign * amount;

  if (after < 0) throw new Error(`العملية مرفوضة: المتاح حاليًا ${before} ${p.unit}.`);

  p.stock = after;
  state.movements.push({
    id: uid("mov"), productId: p.id, productName: p.name,
    type, typeLabel: def.label, qty: def.sign * amount,
    before, after, date: today(), note, reference
  });
  return p;
}

export function sellFromInventory(state, productId, qty, reference) {
  return applyMovement(state, { productId, type: "sale", qty, reference, note: "خصم تلقائي من إنشاء الإيصال" });
}