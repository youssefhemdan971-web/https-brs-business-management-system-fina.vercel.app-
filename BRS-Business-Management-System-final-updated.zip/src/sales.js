import { clampMoney, uid } from "./store.js";

export const INSTALLMENT_OPTIONS = [0, 3, 6, 9, 12, 18, 24, 36];

export function calculateSale({ qty, unitPrice, upfront, installmentCount }) {
  const quantity = Number(qty);
  const price = Number(unitPrice);
  const paid = Number(upfront);
  const count = Number(installmentCount);

  if (![quantity, price, paid, count].every(Number.isFinite)) throw new Error("راجع الكمية والأسعار والأقساط.");
  if (quantity <= 0 || price < 0 || paid < 0 || count < 0 || !Number.isInteger(count)) {
    throw new Error("الكمية وعدد الأقساط يجب أن يكونا أرقامًا صحيحة، والقيم المالية لا يمكن أن تكون سالبة.");
  }
  if (count !== 0 && !INSTALLMENT_OPTIONS.includes(count)) {
    throw new Error("اختر مدة تقسيط من الخيارات المتاحة.");
  }

  const total = clampMoney(quantity * price);
  if (paid > total) throw new Error("المقدم لا يمكن أن يتجاوز الإجمالي.");

  const remaining = clampMoney(total - paid);
  if (count === 0 && remaining > 0) {
    throw new Error("في حالة «بدون تقسيط» يجب سداد كامل الإجمالي.");
  }

  return { quantity, unitPrice: clampMoney(price), upfront: clampMoney(paid), count, total, remaining };
}

function addMonthsLocal(date, months) {
  const d = new Date(date.getTime());
  const originalDay = d.getDate();
  d.setDate(1);
  d.setMonth(d.getMonth() + months);
  const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  d.setDate(Math.min(originalDay, lastDay));
  return d;
}

function localDate(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function buildSchedule(remaining, count, from = new Date()) {
  const amountLeft = clampMoney(remaining);
  if (amountLeft === 0 || count === 0) return [];
  if (!Number.isInteger(count) || count < 1) throw new Error("عدد الأقساط غير صحيح.");

  const regular = clampMoney(amountLeft / count);
  const schedule = [];
  let assigned = 0;

  for (let i = 0; i < count; i++) {
    const amount = i === count - 1 ? clampMoney(amountLeft - assigned) : regular;
    assigned = clampMoney(assigned + amount);
    const dueDate = addMonthsLocal(from, i + 1);
    schedule.push({
      id: uid("ins"),
      date: localDate(dueDate),
      amount,
      status: "unpaid",
      paidAt: null
    });
  }
  return schedule;
}
