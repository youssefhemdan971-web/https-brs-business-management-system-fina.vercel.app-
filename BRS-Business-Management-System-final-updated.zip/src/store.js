const STORAGE_KEY = "daftar-aqsat-pro:v1";

const initialState = {
  session: null,
  settings: {
    companyName: "دفتر الأقساط",
    currency: "جنيه",
    lowStockDefault: 2
  },
  customers: [],
  products: [],
  movements: [],
  receipts: []
};

export function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return structuredClone(initialState);
    return normalize(JSON.parse(raw));
  } catch {
    return structuredClone(initialState);
  }
}

function normalize(data) {
  return {
    ...structuredClone(initialState),
    ...data,
    settings: { ...initialState.settings, ...(data.settings || {}) },
    customers: Array.isArray(data.customers) ? data.customers : [],
    products: Array.isArray(data.products) ? data.products : [],
    movements: Array.isArray(data.movements) ? data.movements : [],
    receipts: Array.isArray(data.receipts) ? data.receipts : []
  };
}

export function saveState(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function resetState() {
  localStorage.removeItem(STORAGE_KEY);
}

export function uid(prefix = "id") {
  return `${prefix}_${crypto.randomUUID?.() || `${Date.now()}_${Math.random().toString(36).slice(2)}`}`;
}

export function today() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function money(value, currency = "جنيه") {
  const n = Number(value || 0);
  return `${n.toLocaleString("ar-EG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency}`;
}

export function clampMoney(value) {
  const n = Number(value || 0);
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;
}

export function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[ch]));
}