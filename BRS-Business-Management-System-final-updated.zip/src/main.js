import { loadState, saveState, resetState, money, uid, today, escapeHtml, clampMoney } from "./store.js";
import { createProduct, updateProduct, applyMovement, findProduct, productByName, stockValue, isLowStock, movementTypes, sellFromInventory } from "./inventory.js";
import { INSTALLMENT_OPTIONS, calculateSale, buildSchedule } from "./sales.js";

let state = loadState();
let route = "dashboard";
const ADMIN_EMAIL = "youssefhemdan971@gmail.com";
const ADMIN_CODE_HASH = "e9638166a5d737fc1a1a53d02d1831db0c9ff36ae32f2a77b18a73697ef6a505";

const app = document.querySelector("#app");

function render() {
  if (!state.session) return renderLogin();
  renderShell();
  const pages = { dashboard, receipt, customers, installments, inventory, archive, admin };
  if (route === "admin" && !(state.session?.email?.toLowerCase() === ADMIN_EMAIL && state.session?.adminUnlocked === true)) {
    route = "dashboard";
  }
  (pages[route] || dashboard)();
}

function renderLogin() {
  app.innerHTML = `
    <main class="login-page">
      <section class="login-card">
        <a class="back-link" href="#" data-action="guest">← الرئيسية</a>
        <h1>تسجيل الدخول</h1>
        <p class="login-sub">نسخة تجريبية: البيانات تُحفظ على هذا المتصفح فقط، وتسجيل الدخول غير مرتبط بخدمة مصادقة حقيقية.</p>
        <button class="google-btn" data-action="demo-login">◉ &nbsp; دخول تجريبي</button>
        <div class="divider"><span>أو بالبريد الإلكتروني</span></div>
        <form id="loginForm" class="stack">
          <label>البريد الإلكتروني<input name="email" type="email" required placeholder="name@example.com"></label>
          <label>كلمة المرور<input name="password" type="password" required minlength="4" placeholder="••••••••"></label>
          <button class="primary wide">دخول</button>
        </form>
        <p class="login-foot">تنبيه: كلمة المرور غير موثّقة بخادم في هذه النسخة التجريبية. لا تستخدم بيانات حساسة قبل إعداد Backend آمن.</p>
      </section>
    </main>`;
  document.querySelector("#loginForm").addEventListener("submit", e => {
    e.preventDefault();
    const email = new FormData(e.currentTarget).get("email").trim();
    state.session = { email: email.toLowerCase(), name: email.split("@")[0], role: email.toLowerCase() === ADMIN_EMAIL ? "owner" : "user", adminUnlocked: false };
    saveState(state); render();
  });
  document.querySelector('[data-action="demo-login"]').onclick = () => {
    state.session = { email: "demo@example.com", name: "Demo", role: "user", adminUnlocked: false };
    saveState(state); render();
  };
}

function renderShell() {
  app.innerHTML = `
  <div class="app-shell">
    <aside class="sidebar">
      <div class="brand"><img class="brand-icon-img" src="./brs-icon.png" alt="BRS"><div><b>BRS</b><small>BUSINESS MANAGEMENT SYSTEM</small></div></div>
      <nav>
        ${navBtn("dashboard","لوحة التحكم","⌂")}
        ${navBtn("receipt","إيصال جديد","+")}
        ${navBtn("customers","العملاء","♙")}
        ${navBtn("installments","الأقساط","◷")}
        ${navBtn("inventory","المخزن","▣")}
        ${navBtn("archive","سجل المعاملات","▤")}
        ${state.session?.email?.toLowerCase() === ADMIN_EMAIL ? navBtn("admin","Admin","⚙") : ""}
      </nav>
      <div class="sidebar-bottom">
        <div class="user-chip"><span class="avatar">${escapeHtml((state.session.name || "A")[0].toUpperCase())}</span><div><b>${escapeHtml(state.session.name)}</b><small>${state.session.role === "owner" ? "Owner" : "مستخدم"}</small></div></div>
        <button class="logout" data-action="logout">تسجيل الخروج</button>
      </div>
    </aside>
    <main class="main">
      <header class="topbar">
        <div><h1 id="pageTitle"></h1><p id="pageSub"></p></div>
        <button class="primary" data-action="new-receipt">+ إيصال جديد</button>
      </header>
      <section id="page"></section>
    </main>
  </div>`;
  document.querySelectorAll(".nav-btn").forEach(b => b.onclick = () => { if (b.dataset.route === "admin") return requestAdminAccess(); route = b.dataset.route; render(); });
  document.querySelector('[data-action="new-receipt"]').onclick = () => { route = "receipt"; render(); };
  document.querySelector('[data-action="logout"]').onclick = () => { state.session = null; saveState(state); route = "dashboard"; render(); };
}

async function requestAdminAccess() {
  if (state.session?.email?.toLowerCase() !== ADMIN_EMAIL) {
    alert("شاشة الأدمن متاحة للحساب المصرح به فقط.");
    return;
  }
  const code = prompt("أدخل رمز الأدمن:");
  if (code === null) return;
  const bytes = new TextEncoder().encode(code);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  const hash = [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
  if (hash !== ADMIN_CODE_HASH) {
    alert("رمز الأدمن غير صحيح.");
    return;
  }
  state.session.adminUnlocked = true;
  saveState(state);
  route = "admin";
  render();
}

function navBtn(r, label, icon) {
  return `<button class="nav-btn ${route === r ? "active" : ""}" data-route="${r}"><span>${icon}</span>${label}</button>`;
}

function setPage(title, sub, html) {
  document.querySelector("#pageTitle").textContent = title;
  document.querySelector("#pageSub").textContent = sub;
  document.querySelector("#page").innerHTML = `<div class="content">${html}</div>`;
}

function stat(title, value, note, tone="") {
  return `<article class="stat-card"><div class="stat-label">${title}</div><div class="stat-value ${tone}">${value}</div><div class="stat-note">${note}</div></article>`;
}

function dashboard() {
  const receivable = state.receipts.reduce((s,r) => s + Number(r.remaining || 0), 0);
  const low = state.products.filter(isLowStock).length;
  const due = state.receipts.flatMap(r => (r.schedule || []).map(x => ({...x, customer:r.customer}))).filter(x => x.status !== "paid" && x.date <= today()).length;
  setPage("لوحة التحكم","نظرة عامة على النظام",`
    <div class="stats-grid">
      ${stat("قيمة المخزون", money(stockValue(state, state.settings.currency), state.settings.currency), "بسعر التكلفة")}
      ${stat("العملاء", state.customers.length, "عميل مسجل")}
      ${stat("إجمالي المتبقي", money(receivable, state.settings.currency), "على العملاء")}
      ${stat("تنبيهات المخزن", low, low ? "أصناف تحتاج متابعة" : "المخزون مستقر", low ? "danger" : "success")}
    </div>
    <div class="two-col">
      <section class="panel"><div class="panel-head"><h2>آخر حركات المخزن</h2><button class="link-btn" data-go="inventory">فتح المخزن</button></div>
      ${state.movements.slice(-7).reverse().map(m => `<div class="list-row"><span>${escapeHtml(m.productName)}<small>${escapeHtml(m.typeLabel)}</small></span><b class="${m.qty >= 0 ? "positive":"negative"}">${m.qty>0?"+":""}${m.qty}</b></div>`).join("") || empty("لا توجد حركات مخزن بعد.")}</section>
      <section class="panel"><div class="panel-head"><h2>أقساط مستحقة</h2><button class="link-btn" data-go="installments">عرض الأقساط</button></div>
      ${state.receipts.flatMap(r => (r.schedule||[]).map(s=>({...s,customer:r.customer}))).filter(s=>s.status!=="paid").slice(0,6).map(s=>`<div class="list-row"><span>${escapeHtml(s.customer)}<small>${s.date}</small></span><b>${money(s.amount,state.settings.currency)}</b></div>`).join("") || empty("لا توجد أقساط غير مسددة.")}</section>
    </div>`);
  document.querySelectorAll("[data-go]").forEach(x=>x.onclick=()=>{route=x.dataset.go;render()});
}

function receipt() {
  const options = state.products.map(p => `<option value="${p.id}">${escapeHtml(p.name)} — المتاح ${p.stock}</option>`).join("");
  setPage("إيصال جديد","تسجيل عملية بيع وتقسيط مع خصم المخزون تلقائيًا",`
  <section class="panel">
    <form id="receiptForm" class="form-grid">
      ${input("customer","العميل / الإقامة","text","",true)}
      ${input("national","الرقم القومي","text")}
      ${input("delegate","اسم المندوب","text")}
      ${input("mobile","رقم التليفون","tel")}
      <label>النوع<select name="type"><option>اختر النوع...</option><option>ملابس</option><option>أجهزة</option><option>أثاث</option><option>أخرى</option></select></label>
      <label>الصنف من المخزن<select name="productId"><option value="">اختر الصنف...</option>${options}</select></label>
      ${input("size","المقاس","text")}
      ${input("qty","الكمية","number","1",true)}
      ${input("price","سعر البيع","number","0",true)}
      <div class="readonly-field"><span>الإجمالي</span><b id="totalValue">0</b></div>
      ${input("paid","المقدم","number","0",true)}
      <div class="readonly-field"><span>الباقي</span><b id="remainingValue">0</b></div>
      ${input("count","عدد الأقساط","number","0",true)}
      <div class="readonly-field"><span>قيمة القسط</span><b id="installmentValue">0</b></div>
      <div class="full installment-choices"><span>التقسيط بالشهور</span><div class="choices">${INSTALLMENT_OPTIONS.map(n=>`<button type="button" class="${n===0?"selected":""}" data-months="${n}">${n===0?"بدون تقسيط":n+" شهر"}</button>`).join("")}</div></div>
      <label class="full">ملاحظات<textarea name="notes" rows="3"></textarea></label>
      <div class="form-actions full"><button class="primary">حفظ وطباعة الوصل</button></div>
    </form>
  </section>
  <section class="panel table-panel"><div class="panel-head"><h2>سجل المعاملات</h2><input id="miniSearch" class="search" placeholder="بحث بالاسم أو الموبايل أو الرقم..."></div><div id="miniTable"></div></section>`);

  const form = document.querySelector("#receiptForm");
  const qty = form.qty, price = form.price, paid = form.paid, count = form.count;
  const recalc = () => {
    const q = Number(qty.value || 0);
    const p = Number(price.value || 0);
    const paidValue = Number(paid.value || 0);
    const c = Number(count.value || 0);
    const total = Number.isFinite(q) && Number.isFinite(p) ? clampMoney(q * p) : 0;
    const upfrontValue = Number.isFinite(paidValue) ? clampMoney(paidValue) : 0;
    const remaining = Math.max(0, clampMoney(total - upfrontValue));
    const installment = Number.isInteger(c) && c > 0 ? clampMoney(remaining / c) : 0;
    document.querySelector("#totalValue").textContent=money(total,state.settings.currency);
    document.querySelector("#remainingValue").textContent=money(remaining,state.settings.currency);
    document.querySelector("#installmentValue").textContent=money(installment,state.settings.currency);
  };
  [qty,price,paid,count].forEach(x=>x.addEventListener("input",recalc));
  form.productId.addEventListener("change",()=>{ const p=findProduct(state,form.productId.value); if(p){form.price.value=p.price; recalc();}});
  document.querySelectorAll("[data-months]").forEach(b=>b.onclick=()=>{count.value=b.dataset.months;document.querySelectorAll("[data-months]").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");recalc()});
  form.addEventListener("submit", e => {
    e.preventDefault();
    try {
      const data = new FormData(form);
      const customer = String(data.get("customer")||"").trim();
      const productId = String(data.get("productId")||"");
      const calc = calculateSale({ qty: data.get("qty"), unitPrice: data.get("price"), upfront: data.get("paid"), installmentCount: data.get("count") });
      if(!customer || !productId) throw new Error("العميل والصنف مطلوبان.");
      const product=findProduct(state,productId);
      if(!product) throw new Error("الصنف غير موجود.");
      if(calc.quantity>product.stock) throw new Error(`المتاح في المخزن ${product.stock} ${product.unit} فقط.`);
      const schedule=buildSchedule(calc.remaining, calc.count);
      sellFromInventory(state,productId,calc.quantity);
      const receipt={id:uid("rec"),customer,national:String(data.get("national")||""),delegate:String(data.get("delegate")||""),mobile:String(data.get("mobile")||""),type:String(data.get("type")||""),productId,product:product.name,size:String(data.get("size")||""),qty:calc.quantity,unitPrice:calc.unitPrice,total:calc.total,paid:calc.upfront,remaining:calc.remaining,schedule,notes:String(data.get("notes")||""),createdAt:new Date().toISOString()};
      state.receipts.push(receipt);
      let c=state.customers.find(x=>x.name===customer);
      if(!c) state.customers.push({id:uid("cus"),name:customer,national:receipt.national,mobile:receipt.mobile,createdAt:new Date().toISOString()});
      saveState(state); alert("تم حفظ الإيصال وخصم الكمية من المخزن."); printReceipt(receipt); route="archive"; render();
    } catch(err){alert(err.message)}
  });
  drawMiniReceipts();
  document.querySelector("#miniSearch").oninput=drawMiniReceipts;
  recalc();
}

function drawMiniReceipts(){
  const q=(document.querySelector("#miniSearch")?.value||"").toLowerCase();
  const list=state.receipts.filter(r=>(r.customer+r.mobile+r.national).toLowerCase().includes(q)).slice(-8).reverse();
  const el=document.querySelector("#miniTable"); if(!el)return;
  el.innerHTML=list.length?`<div class="table-scroll"><table><thead><tr><th>#</th><th>العميل</th><th>الموبايل</th><th>الإجمالي</th><th>الباقي</th><th>التاريخ</th></tr></thead><tbody>${list.map((r,i)=>`<tr><td>${i+1}</td><td>${escapeHtml(r.customer)}</td><td>${escapeHtml(r.mobile)}</td><td>${money(r.total,state.settings.currency)}</td><td>${money(r.remaining,state.settings.currency)}</td><td>${r.createdAt.slice(0,10)}</td></tr>`).join("")}</tbody></table></div>`:empty("لا توجد إيصالات بعد.");
}

function input(name,label,type="text",value="",required=false){return `<label>${label}${required?" *":""}<input name="${name}" type="${type}" value="${escapeHtml(value)}" ${required?"required":""}></label>`}
function empty(t){return `<div class="empty">${t}</div>`}

function customers(){
 setPage("العملاء","بيانات العملاء وسجل تعاملاتهم",`<section class="panel"><div class="panel-head"><h2>العملاء</h2><div class="toolbar"><input id="customerSearch" class="search" placeholder="بحث..."><button class="primary" id="addCustomer">+ إضافة عميل</button></div></div><div id="customerTable"></div></section>`);
 const draw=()=>{const q=(document.querySelector("#customerSearch").value||"").toLowerCase();const rows=state.customers.filter(c=>(c.name+c.mobile+c.national).toLowerCase().includes(q));document.querySelector("#customerTable").innerHTML=rows.length?table(["العميل","الموبايل","الرقم القومي","المعاملات"],rows.map(c=>[escapeHtml(c.name),escapeHtml(c.mobile),escapeHtml(c.national),state.receipts.filter(r=>r.customer===c.name).length])):empty("لا توجد بيانات عملاء.");};
 document.querySelector("#customerSearch").oninput=draw; document.querySelector("#addCustomer").onclick=()=>customerModal(); draw();
}

function customerModal(existing=null){
 modal(existing?"تعديل العميل":"إضافة عميل",`<form id="customerForm" class="stack">${input("name","اسم العميل","text",existing?.name||"",true)}${input("national","الرقم القومي","text",existing?.national||"")}${input("mobile","رقم التليفون","tel",existing?.mobile||"")}<button class="primary">حفظ</button></form>`);
 document.querySelector("#customerForm").onsubmit=e=>{e.preventDefault();const f=new FormData(e.currentTarget);const data={name:String(f.get("name")).trim(),national:String(f.get("national")||""),mobile:String(f.get("mobile")||"")};if(existing)Object.assign(existing,data);else state.customers.push({id:uid("cus"),...data,createdAt:new Date().toISOString()});saveState(state);closeModal();customers();}
}

function installments(){
 const rows=state.receipts.flatMap(r=>(r.schedule||[]).map(s=>({...s,customer:r.customer,receiptId:r.id})));
 setPage("الأقساط","متابعة الأقساط والتحصيل",`<section class="panel"><div class="panel-head"><h2>جدول الأقساط</h2><input id="instSearch" class="search" placeholder="بحث باسم العميل"></div><div id="instTable"></div></section>`);
 const draw=()=>{const q=(document.querySelector("#instSearch").value||"").toLowerCase();const list=rows.filter(x=>x.customer.toLowerCase().includes(q));document.querySelector("#instTable").innerHTML=list.length?`<div class="table-scroll"><table><thead><tr><th>العميل</th><th>التاريخ</th><th>القيمة</th><th>الحالة</th><th></th></tr></thead><tbody>${list.map(s=>`<tr><td>${escapeHtml(s.customer)}</td><td>${s.date}</td><td>${money(s.amount,state.settings.currency)}</td><td><span class="badge ${s.status==="paid"?"success":"warning"}">${s.status==="paid"?"مسدد":"غير مسدد"}</span></td><td>${s.status==="paid"?"":`<button class="small success-btn" data-pay="${s.receiptId}|${s.id}">تسجيل سداد</button>`}</td></tr>`).join("")}</tbody></table></div>`:empty("لا توجد أقساط.");document.querySelectorAll("[data-pay]").forEach(b=>b.onclick=()=>{const [rid,sid]=b.dataset.pay.split("|");const r=state.receipts.find(x=>x.id===rid);const s=r?.schedule.find(x=>x.id===sid);if(s && s.status!=="paid"){s.status="paid";s.paidAt=new Date().toISOString();s.paidAmount=s.amount;r.paid=clampMoney(Number(r.paid||0)+Number(s.amount||0));r.remaining=Math.max(0,clampMoney(Number(r.total||0)-r.paid));saveState(state);installments();}})};document.querySelector("#instSearch").oninput=draw;draw();
}

function inventory(){
 setPage("المخزن","مخزن البضاعة — إدخال وإخراج وحركة الأصناف",`
 <section class="panel">
   <div class="inventory-kpis">
     ${stat("عدد الأصناف",state.products.length,"")}
     ${stat("الوحدات",state.products.reduce((s,p)=>s+Number(p.stock||0),0),"إجمالي الكمية")}
     ${stat("قيمة المخزون",money(stockValue(state),state.settings.currency),"بسعر التكلفة")}
     ${stat("منخفض",state.products.filter(isLowStock).length,"أصناف تحتاج شراء")}
   </div>
   <div class="panel-head"><h2>البضاعة</h2><div class="toolbar"><input id="invSearch" class="search" placeholder="بحث باسم الصنف أو الكود"><button class="primary" id="addProduct">+ إضافة بضاعة</button><button class="secondary" id="movementBtn">تسجيل حركة</button><button class="secondary" id="csvBtn">تصدير CSV</button></div></div>
   <div id="inventoryTable"></div>
 </section>
 <section class="panel"><div class="panel-head"><h2>سجل حركات المخزن</h2></div><div id="movementTable"></div></section>`);
 const draw=()=>{
   const q=(document.querySelector("#invSearch").value||"").toLowerCase();
   const list=state.products.filter(p=>(p.name+p.sku+p.category).toLowerCase().includes(q));
   document.querySelector("#inventoryTable").innerHTML=list.length?`<div class="table-scroll"><table><thead><tr><th>الصنف</th><th>الكود</th><th>الفئة</th><th>المتاح</th><th>شراء</th><th>بيع</th><th>الحالة</th><th>إجراءات</th></tr></thead><tbody>${list.map(p=>`<tr class="${p.stock===0?"row-danger":isLowStock(p)?"row-warning":""}"><td><b>${escapeHtml(p.name)}</b><small>${escapeHtml(p.size)} ${escapeHtml(p.unit)}</small></td><td>${escapeHtml(p.sku)}</td><td>${escapeHtml(p.category)}</td><td><b>${p.stock}</b></td><td>${money(p.cost,state.settings.currency)}</td><td>${money(p.price,state.settings.currency)}</td><td><span class="badge ${p.stock===0?"danger":isLowStock(p)?"warning":"success"}">${p.stock===0?"نفد":isLowStock(p)?"منخفض":"متوفر"}</span></td><td><button class="small success-btn" data-move="${p.id}">± كمية</button> <button class="small secondary" data-edit="${p.id}">تعديل</button></td></tr>`).join("")}</tbody></table></div>`:empty("لا توجد بضاعة. اضغط «إضافة بضاعة».");
   document.querySelectorAll("[data-move]").forEach(b=>b.onclick=()=>movementModal(b.dataset.move));
   document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>productModal(findProduct(state,b.dataset.edit)));
 };
 document.querySelector("#invSearch").oninput=draw;
 document.querySelector("#addProduct").onclick=()=>productModal();
 document.querySelector("#movementBtn").onclick=()=>movementModal();
 document.querySelector("#csvBtn").onclick=exportInventory;
 draw();
 const moves=state.movements.slice().reverse().slice(0,40);
 document.querySelector("#movementTable").innerHTML=moves.length?`<div class="table-scroll"><table><thead><tr><th>التاريخ</th><th>الصنف</th><th>الحركة</th><th>الكمية</th><th>قبل</th><th>بعد</th><th>المرجع</th></tr></thead><tbody>${moves.map(m=>`<tr><td>${m.date}</td><td>${escapeHtml(m.productName)}</td><td>${escapeHtml(m.typeLabel)}</td><td class="${m.qty>=0?"positive":"negative"}">${m.qty>0?"+":""}${m.qty}</td><td>${m.before??"-"}</td><td>${m.after??"-"}</td><td>${escapeHtml(m.reference||"")}</td></tr>`).join("")}</tbody></table></div>`:empty("لا توجد حركات.");
}

function productModal(product=null){
 modal(product?"تعديل البضاعة":"إضافة بضاعة",`<form id="productForm" class="form-grid">
 ${input("name","اسم الصنف","text",product?.name||"",true)}
 ${input("sku","كود الصنف","text",product?.sku||"",true)}
 ${input("category","الفئة","text",product?.category||"عام")}
 ${input("size","المقاس","text",product?.size||"")}
 ${input("unit","الوحدة","text",product?.unit||"قطعة")}
 ${input("stock","الكمية الحالية","number",product?.stock??0,true)}
 ${input("cost","سعر الشراء","number",product?.cost??0,true)}
 ${input("price","سعر البيع","number",product?.price??0,true)}
 ${input("reorderLevel","حد إعادة الطلب","number",product?.reorderLevel??state.settings.lowStockDefault,true)}
 <div class="full form-actions"><button class="primary">حفظ الصنف</button></div></form>`);
 document.querySelector("#productForm").onsubmit=e=>{e.preventDefault();try{const d=Object.fromEntries(new FormData(e.currentTarget).entries());if(product)updateProduct(state,product.id,d);else createProduct(state,d);saveState(state);closeModal();inventory();}catch(err){alert(err.message)}};
}

function movementModal(preselected=null){
 if(!state.products.length){alert("أضف بضاعة أولًا.");return}
 modal("تسجيل حركة مخزن",`<form id="movementForm" class="stack">
 <label>الصنف<select name="productId">${state.products.map(p=>`<option value="${p.id}" ${p.id===preselected?"selected":""}>${escapeHtml(p.name)} — المتاح ${p.stock}</option>`).join("")}</select></label>
 <label>نوع الحركة<select name="type">${Object.entries(movementTypes).filter(([k])=>k!=="sale").map(([k,v])=>`<option value="${k}">${v.label}</option>`).join("")}</select></label>
 ${input("qty","الكمية","number","1",true)}
 ${input("reference","رقم الفاتورة / المرجع")}
 <label>ملاحظات<textarea name="note" rows="3"></textarea></label>
 <button class="primary">تنفيذ الحركة</button></form>`);
 document.querySelector("#movementForm").onsubmit=e=>{e.preventDefault();try{const d=new FormData(e.currentTarget);applyMovement(state,{productId:d.get("productId"),type:d.get("type"),qty:d.get("qty"),reference:d.get("reference"),note:d.get("note")});saveState(state);closeModal();inventory();}catch(err){alert(err.message)}};
}

function archive(){
 setPage("أرشيف المعاملات","كل الإيصالات المحفوظة في هذا المتصفح — بحث وتفاصيل وطباعة وتصدير",`
 <div class="stats-grid archive-stats" id="archiveStats"></div>
 <section class="panel">
  <div class="panel-head"><h2>سجل الإيصالات</h2><div class="toolbar"><input id="archSearch" class="search" placeholder="ابحث بالعميل أو الهاتف أو الرقم القومي أو الصنف أو رقم الإيصال"><button class="secondary" id="exportReceipts">تصدير النتائج CSV</button></div></div>
  <div class="archive-filters toolbar"><label>من تاريخ<input id="archFrom" type="date"></label><label>إلى تاريخ<input id="archTo" type="date"></label><label>حالة الرصيد<select id="archStatus"><option value="all">كل المعاملات</option><option value="remaining">لها مبالغ متبقية</option><option value="settled">مسددة بالكامل</option></select></label></div>
  <div id="archTable"></div>
 </section>`);
 const draw=()=>{
  const q=(document.querySelector("#archSearch").value||"").trim().toLocaleLowerCase();
  const from=document.querySelector("#archFrom").value;
  const to=document.querySelector("#archTo").value;
  const status=document.querySelector("#archStatus").value;
  const list=state.receipts.filter(r=>{
   const created=String(r.createdAt||"").slice(0,10);
   const searchable=[r.id,r.customer,r.mobile,r.product,r.national,r.delegate,r.type,r.notes].join(" ").toLocaleLowerCase();
   if(q&&!searchable.includes(q)) return false;
   if(from&&created<from) return false;
   if(to&&created>to) return false;
   if(status==="remaining"&&Number(r.remaining||0)<=0) return false;
   if(status==="settled"&&Number(r.remaining||0)>0) return false;
   return true;
  }).slice().reverse();
  const total=list.reduce((sum,r)=>sum+Number(r.total||0),0);
  const paid=list.reduce((sum,r)=>sum+Number(r.paid||0),0);
  const remaining=list.reduce((sum,r)=>sum+Number(r.remaining||0),0);
  document.querySelector("#archiveStats").innerHTML=[stat("عدد الإيصالات",list.length,"حسب البحث والفلاتر"),stat("إجمالي المبيعات",money(total,state.settings.currency),"إجمالي النتائج"),stat("المبالغ المحصلة",money(paid,state.settings.currency),"المقدم والسداد المسجل"),stat("المتبقي للتحصيل",money(remaining,state.settings.currency),"على النتائج المعروضة","danger")].join("");
  document.querySelector("#archTable").innerHTML=list.length?`<div class="table-scroll"><table><thead><tr><th>رقم الإيصال</th><th>العميل</th><th>الهاتف</th><th>الصنف</th><th>الإجمالي</th><th>المدفوع</th><th>المتبقي</th><th>التاريخ</th><th>الإجراءات</th></tr></thead><tbody>${list.map(r=>`<tr><td><code>${escapeHtml(r.id)}</code></td><td><b>${escapeHtml(r.customer)}</b><small>${escapeHtml(r.national||"")}</small></td><td>${escapeHtml(r.mobile||"—")}</td><td>${escapeHtml(r.product||"—")}<small>الكمية: ${Number(r.qty||0)}</small></td><td>${money(r.total,state.settings.currency)}</td><td>${money(r.paid,state.settings.currency)}</td><td><span class="badge ${Number(r.remaining||0)>0?"warning":"success"}">${money(r.remaining,state.settings.currency)}</span></td><td>${escapeHtml(String(r.createdAt||"").slice(0,10)||"—")}</td><td><div class="toolbar"><button class="small secondary" data-view-receipt="${escapeHtml(r.id)}">التفاصيل</button><button class="small secondary" data-print="${escapeHtml(r.id)}">طباعة</button></div></td></tr>`).join("")}</tbody></table></div>`:empty("لا توجد معاملات مطابقة للفلاتر الحالية.");
  document.querySelectorAll("[data-print]").forEach(b=>b.onclick=()=>printReceipt(state.receipts.find(r=>r.id===b.dataset.print)));
  document.querySelectorAll("[data-view-receipt]").forEach(b=>b.onclick=()=>showReceiptDetails(state.receipts.find(r=>r.id===b.dataset.viewReceipt)));
  document.querySelector("#exportReceipts").onclick=()=>exportReceipts(list);
 };
 ["#archSearch","#archFrom","#archTo","#archStatus"].forEach(sel=>document.querySelector(sel).addEventListener(sel==="#archSearch"?"input":"change",draw));
 draw();
}

function showReceiptDetails(r){
 if(!r)return;
 const schedule=(r.schedule||[]).map(s=>`<tr><td>${escapeHtml(s.date||"—")}</td><td>${money(s.amount,state.settings.currency)}</td><td><span class="badge ${s.status==="paid"?"success":"warning"}">${s.status==="paid"?"مسدد":"غير مسدد"}</span></td><td>${escapeHtml(s.paidAt?String(s.paidAt).slice(0,10):"—")}</td></tr>`).join("");
 modal("تفاصيل الإيصال",`<div class="receipt-details"><div class="detail-grid"><div><small>رقم الإيصال</small><b>${escapeHtml(r.id)}</b></div><div><small>تاريخ الإنشاء</small><b>${escapeHtml(String(r.createdAt||"").slice(0,10)||"—")}</b></div><div><small>اسم العميل</small><b>${escapeHtml(r.customer||"—")}</b></div><div><small>رقم الهاتف</small><b>${escapeHtml(r.mobile||"—")}</b></div><div><small>الرقم القومي</small><b>${escapeHtml(r.national||"—")}</b></div><div><small>المندوب</small><b>${escapeHtml(r.delegate||"—")}</b></div><div><small>الصنف</small><b>${escapeHtml(r.product||"—")}</b></div><div><small>الكمية / المقاس</small><b>${Number(r.qty||0)} / ${escapeHtml(r.size||"—")}</b></div></div><div class="stats-grid detail-money">${stat("الإجمالي",money(r.total,state.settings.currency),"قيمة البيع")}${stat("المدفوع",money(r.paid,state.settings.currency),"المقدم والسداد")}${stat("المتبقي",money(r.remaining,state.settings.currency),"الرصيد الحالي",Number(r.remaining||0)>0?"danger":"success")}</div><h3>جدول الأقساط</h3>${schedule?`<div class="table-scroll"><table><thead><tr><th>تاريخ الاستحقاق</th><th>قيمة القسط</th><th>الحالة</th><th>تاريخ السداد</th></tr></thead><tbody>${schedule}</tbody></table></div>`:empty("لا يوجد جدول أقساط لهذه المعاملة.")}<p><b>ملاحظات:</b> ${escapeHtml(r.notes||"لا توجد ملاحظات")}</p><div class="toolbar"><button class="primary" id="detailPrint">طباعة الإيصال</button></div></div>`);
 document.querySelector("#detailPrint").onclick=()=>printReceipt(r);
}

function admin(){
 const receivable=state.receipts.reduce((sum,r)=>sum+Number(r.remaining||0),0);
 const sales=state.receipts.reduce((sum,r)=>sum+Number(r.total||0),0);
 const collected=state.receipts.reduce((sum,r)=>sum+Number(r.paid||0),0);
 const overdue=state.receipts.flatMap(r=>(r.schedule||[]).map(i=>({...i,customer:r.customer,receiptId:r.id}))).filter(i=>i.status!=="paid"&&i.date<today());
 const lowStock=state.products.filter(isLowStock).length;
 setPage("لوحة الأدمن","إدارة النظام ومراجعة النشاط والنسخ الاحتياطي",`
  <div class="admin-notice"><b>تنبيه أمان:</b> هذه النسخة تحفظ البيانات محليًا في المتصفح؛ شاشة الأدمن ورمزها لا يوفران حماية خادمية حقيقية. لا تستخدم بيانات عملاء حساسة قبل ربط مصادقة وقاعدة بيانات آمنتين.</div>
  <div class="stats-grid admin-stats">${stat("إجمالي المبيعات",money(sales,state.settings.currency),`${state.receipts.length} إيصال`)}${stat("المبالغ المحصلة",money(collected,state.settings.currency),"المبالغ المسجلة كمدفوعة","success")}${stat("المتبقي للتحصيل",money(receivable,state.settings.currency),"إجمالي أرصدة الإيصالات","danger")}${stat("العملاء",state.customers.length,"عدد سجلات العملاء")}${stat("أصناف المخزن",state.products.length,"عدد الأصناف")}${stat("أصناف منخفضة المخزون",lowStock,"تحتاج مراجعة",lowStock?"danger":"success")}${stat("أقساط متأخرة",overdue.length,"تاريخ استحقاقها مرّ ولم تُسدد",overdue.length?"danger":"success")}</div>
  <div class="admin-actions panel"><h2>اختصارات سريعة</h2><div class="toolbar"><button class="primary" id="adminArchive">فتح الأرشيف</button><button class="secondary" id="adminInventory">فتح المخزن</button><button class="secondary" id="adminBackup">تنزيل نسخة احتياطية</button><button class="secondary" id="adminExport">تصدير الإيصالات CSV</button></div></div>
  <div class="two-col"><section class="panel"><h2>إعدادات عامة</h2><form id="settingsForm" class="stack">${input("companyName","اسم المنشأة","text",state.settings.companyName,true)}${input("currency","العملة","text",state.settings.currency,true)}${input("lowStockDefault","حد المخزون الافتراضي","number",state.settings.lowStockDefault,true)}<button class="primary">حفظ الإعدادات</button></form></section><section class="panel"><h2>البيانات والنسخ الاحتياطي</h2><p class="muted">صدّر نسخة تشمل العملاء والمخزن وحركات المخزون والإيصالات والأقساط، واحفظها في مكان آمن.</p><div class="toolbar"><button class="secondary" id="backup">تنزيل نسخة احتياطية JSON</button><label class="secondary file-btn">استعادة نسخة JSON <input id="restore" type="file" accept=".json,application/json"></label><button class="danger-btn" id="reset">مسح بيانات هذا المتصفح</button></div><p class="muted small-note">الاستعادة تستبدل البيانات المحلية الحالية؛ نزّل نسخة احتياطية أولًا.</p></section></div>
  <section class="panel"><div class="panel-head"><h2>أحدث المعاملات</h2><button class="link-btn" id="adminAllReceipts">عرض الأرشيف ←</button></div>${state.receipts.length?`<div class="table-scroll"><table><thead><tr><th>العميل</th><th>الصنف</th><th>الإجمالي</th><th>المتبقي</th><th>التاريخ</th></tr></thead><tbody>${state.receipts.slice().reverse().slice(0,6).map(r=>`<tr><td>${escapeHtml(r.customer||"—")}</td><td>${escapeHtml(r.product||"—")}</td><td>${money(r.total,state.settings.currency)}</td><td>${money(r.remaining,state.settings.currency)}</td><td>${escapeHtml(String(r.createdAt||"").slice(0,10)||"—")}</td></tr>`).join("")}</tbody></table></div>`:empty("لا توجد معاملات مسجلة بعد.")}</section>`);
 document.querySelector("#settingsForm").onsubmit=e=>{e.preventDefault();const f=new FormData(e.currentTarget);state.settings.companyName=String(f.get("companyName"));state.settings.currency=String(f.get("currency"));state.settings.lowStockDefault=Number(f.get("lowStockDefault"));saveState(state);alert("تم حفظ الإعدادات.");admin()};
 document.querySelector("#backup").onclick=backup;
 document.querySelector("#adminBackup").onclick=backup;
 document.querySelector("#adminExport").onclick=()=>exportReceipts();
 document.querySelector("#adminArchive").onclick=()=>{route="archive";render()};
 document.querySelector("#adminAllReceipts").onclick=()=>{route="archive";render()};
 document.querySelector("#adminInventory").onclick=()=>{route="inventory";render()};
 document.querySelector("#restore").onchange=e=>{const file=e.target.files[0];if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const parsed=JSON.parse(reader.result);if(!Array.isArray(parsed.products)||!Array.isArray(parsed.receipts)||!Array.isArray(parsed.customers))throw new Error();if(!confirm("سيتم استبدال البيانات المحلية الحالية بالنسخة المختارة. هل تريد المتابعة؟"))return;state={...parsed,session:state.session,settings:{...state.settings,...(parsed.settings||{})}};saveState(state);alert("تمت استعادة النسخة بنجاح.");render()}catch{alert("النسخة الاحتياطية غير صالحة أو ناقصة.")}};reader.readAsText(file)};
 document.querySelector("#reset").onclick=()=>{if(confirm("تحذير: سيتم حذف بيانات BRS المحفوظة في هذا المتصفح فقط. تأكد من تنزيل نسخة احتياطية. هل تريد المتابعة؟")){resetState();state=loadState();renderLogin()}};
}

function table(headers, rows){return `<div class="table-scroll"><table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`}

function modal(title,html){let old=document.querySelector("#modal");if(old)old.remove();document.body.insertAdjacentHTML("beforeend",`<div class="modal" id="modal"><div class="modal-card"><div class="modal-head"><h2>${title}</h2><button class="close" data-close>×</button></div>${html}</div></div>`);document.querySelector("[data-close]").onclick=closeModal}
function closeModal(){document.querySelector("#modal")?.remove()}

function printReceipt(r){
 if(!r)return;
 const w=window.open("","_blank","width=760,height=900");
 if(!w){alert("اسمح للمتصفح بفتح نافذة الطباعة.");return}
 w.document.write(`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>إيصال ${escapeHtml(r.id)}</title><style>body{font-family:Arial;padding:35px;line-height:1.8}h1{margin:0}table{width:100%;border-collapse:collapse;margin-top:20px}td,th{border:1px solid #ccc;padding:8px;text-align:right}@media print{button{display:none}}</style></head><body><h1>${escapeHtml(state.settings.companyName)}</h1><p>إيصال بيع وتقسيط</p><hr><p><b>العميل:</b> ${escapeHtml(r.customer)}<br><b>الموبايل:</b> ${escapeHtml(r.mobile)}<br><b>الصنف:</b> ${escapeHtml(r.product)}<br><b>الكمية:</b> ${r.qty}</p><table><tr><th>الإجمالي</th><th>المقدم</th><th>الباقي</th></tr><tr><td>${money(r.total,state.settings.currency)}</td><td>${money(r.paid,state.settings.currency)}</td><td>${money(r.remaining,state.settings.currency)}</td></tr></table><h3>جدول الأقساط</h3>${r.schedule?.length?r.schedule.map(s=>`<p>${s.date} — ${money(s.amount,state.settings.currency)} — ${s.status==="paid"?"مسدد":"غير مسدد"}</p>`).join(""):"<p>بدون تقسيط</p>"}<button onclick="print()">طباعة</button></body></html>`);w.document.close();
}

function exportCSV(){
 const rows=[["الصنف","الكود","الفئة","الكمية","سعر الشراء","سعر البيع"],...state.products.map(p=>[p.name,p.sku,p.category,p.stock,p.cost,p.price])];
 download("المخزن.csv","\uFEFF"+rows.map(r=>r.map(x=>`"${String(x??"").replaceAll('"','""')}"`).join(",")).join("\n"),"text/csv;charset=utf-8");
}
function exportInventory(){exportCSV()}
function exportReceipts(receipts=state.receipts){
 const rows=[["رقم الإيصال","العميل","الهاتف","الرقم القومي","المندوب","الصنف","الكمية","الإجمالي","المدفوع","الباقي","التاريخ"],...receipts.map(r=>[r.id,r.customer,r.mobile,r.national,r.delegate,r.product,r.qty,r.total,r.paid,r.remaining,String(r.createdAt||"").slice(0,10)])];
 download("أرشيف-الإيصالات.csv","\uFEFF"+rows.map(r=>r.map(x=>`"${String(x??"").replaceAll('"','""')}"`).join(",")).join("\n"),"text/csv;charset=utf-8");
}
function download(name,data,type){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([data],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function backup(){download("دفتر-الأقساط-backup.json",JSON.stringify(state,null,2),"application/json")}

document.addEventListener("click", e => {
 if(e.target.matches("[data-close]")) closeModal();
});
render();
